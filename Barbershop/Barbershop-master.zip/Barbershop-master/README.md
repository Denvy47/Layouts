Проходил курс по верстке.
Верстка доступна по [ссылке](https://denvy47.github.io/Barbershop/code/index.html)

Сверстана главная страница с использованием только HTML/CSS (без JS)
